// Namespaces used for ECHO Forms
export const namespaces = {
  xmlns: 'http://echo.nasa.gov/v9/echoforms',
  ecs: 'http://ecs.nasa.gov/options',
  info: 'http://eosdis.nasa.gov/esi/info'
}
