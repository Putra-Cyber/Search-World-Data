export const retrievalPayload = {
  pathParameters: {
    id: 2
  }
}
