export const collectionDetailsRow = [
  {
    shape: 'rectangle',
    left: 0,
    top: 3,
    height: 12,
    width: 225,
    radius: 2
  }
]

export const collectionDetailsParagraph = [
  {
    shape: 'rectangle',
    left: 0,
    top: 3,
    height: 12,
    width: 225,
    radius: 2
  },
  {
    shape: 'rectangle',
    left: 0,
    top: 23,
    height: 12,
    width: 225,
    radius: 2
  },
  {
    shape: 'rectangle',
    left: 0,
    top: 43,
    height: 12,
    width: 225,
    radius: 2
  }
]
