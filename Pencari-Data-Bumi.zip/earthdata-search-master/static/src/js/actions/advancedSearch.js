import { UPDATE_ADVANCED_SEARCH } from '../constants/actionTypes'

export const updateAdvancedSearch = payload => ({
  type: UPDATE_ADVANCED_SEARCH,
  payload
})
