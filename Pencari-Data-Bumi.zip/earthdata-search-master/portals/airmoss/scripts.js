import logo from './images/ornl-daac-logo-color.png'

// Pre-load logo hover image
const image = new Image()
image.src = logo
