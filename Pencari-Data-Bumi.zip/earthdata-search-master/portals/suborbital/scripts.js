import logo from './images/suborbital-icon-grey-clear.png'

// Pre-load logo hover image
const image = new Image()
image.src = logo
